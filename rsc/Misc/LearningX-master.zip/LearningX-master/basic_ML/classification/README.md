# Basic Machine Learning algorithms: Classificattion

<p align="center"> 
<img src="images/coverart.png" width="25%">
</p>

* Decision Tree (`decision_tree.py`)

* K nearest neighbours (`knn.py`)



### Usage

Run `python3` on any of the files

* `decision_tree.py`
* `knn.py`


### Libraries

* numpy, pandas



### Author

Anson Wong