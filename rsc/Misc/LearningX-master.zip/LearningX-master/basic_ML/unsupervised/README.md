# Basic Machine Learning algorithms: Unsupervised Learning

<p align="center"> 
<img src="images/coverart.png" width="25%">
</p>

* K-means clustering (`kmeans.py`)

### Usage

Run `python3` on any of the files

* `kmeans.py`

### Libraries

* numpy, pandas



### Author

Anson Wong